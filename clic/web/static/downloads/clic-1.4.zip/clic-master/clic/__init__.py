'''
Corpus Linguistics in Cheshire3 (CLiC).
'''

__name__ = "clic"
__package__ = "clic"
__all__ = ['stats', 'web', 'normalizer']
